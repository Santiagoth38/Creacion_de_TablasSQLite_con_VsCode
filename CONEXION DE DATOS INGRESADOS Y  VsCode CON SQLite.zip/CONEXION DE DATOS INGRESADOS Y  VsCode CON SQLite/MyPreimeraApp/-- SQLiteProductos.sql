-- SQLiteProductos


SELECT * FROM Productos;