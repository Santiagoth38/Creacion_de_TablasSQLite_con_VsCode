﻿// See https://aka.ms/new-console-template for more information

using System;
using Microsoft.Data.Sqlite;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace MyPreimeraApp


{
class Program
{
        //private static object connection = null!;

        

        static void Main(string[] args){

//CREATE CONECTION

var connectionStringBuilder = new SqliteConnectionStringBuilder();

connectionStringBuilder.DataSource = ".Productos.db";

using(var connection = new SqliteConnection(connectionStringBuilder.ConnectionString)){

connection.Open();

//CREATE TABLE

var tableCd = connection.CreateCommand();   // FILAS

tableCd.CommandText = "CREATE TABLE Productos (Nombre VARCHAR(50), Referencia VARCHAR(50), Año VARCHAR(50), Vence VARCHAR(50));"; //En la explicacion dice tableCmd por lo que es en windows
//pero como estoy trabajando en linux se pone tableCd...

tableCd.ExecuteNonQuery();

     




//INSERT SOME RECORDS

using(var transaction = connection.BeginTransaction()){

var insertCd = connection.CreateCommand();
insertCd.CommandText = "INSERT INTO  Productos VALUES('Amazonas','Tierra fertil', '2023' , 'N/A')";
insertCd.ExecuteNonQuery();


insertCd.CommandText = "INSERT INTO  Productos VALUES('Frutas','Del campo', '2023', '2024' )";     //COLUMNAS
insertCd.ExecuteNonQuery();


insertCd.CommandText = "INSERT INTO  Productos VALUES('Santiagoth','Vendedor', '2023' , 'N/A')";
insertCd.ExecuteNonQuery();

transaction.Commit();

}


//READ RECORDS
var selectCd = connection.CreateCommand();

selectCd.CommandText = "SELECT * FROM Productos";

using(var reader = selectCd.ExecuteReader()){
        while(reader.Read()){
                var result = reader.GetString(0);
                Console.WriteLine(result);


        }
}


}


/* NOTA: EN ESTE EJERCICIO CUANDO SE CREA LA BASE DE DATOS SQLITE CON " dotnet run " SOLO 
APARECE LA PRIMERA COLUMNA PERO EN LA BASE DE DATOS SQLITE APArECEN TODAS...

DADO ESTO ANTERIOR SE INTRODUJO UNA FUNCION "SQLite NewQuery" PARA INVOCAR Y VISUALIZAR 
LA TABLA DESDE EL VSCODE. 

*/

     }
   }

}




   